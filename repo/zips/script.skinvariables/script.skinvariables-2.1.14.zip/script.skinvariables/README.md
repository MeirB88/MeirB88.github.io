# script.skinvariables
A helper script for Kodi skinners to construct multiple variables

## Wiki
[Variable Builder](https://github.com/jurialmunkey/script.skinvariables/wiki/Skin-Variable-Builder)
[Viewtype Builder](https://github.com/jurialmunkey/script.skinvariables/wiki/Skin-Viewtype-Builder)

## Kodi Versions

- [Leia](https://github.com/jurialmunkey/script.skinvariables/tree/leia)
- [Matrix](https://github.com/jurialmunkey/script.skinvariables/tree/matrix)
- [Nexus](https://github.com/jurialmunkey/script.skinvariables/tree/nexus)
